export class Pedido {
   IDCliente: string;
   pedido: string;
}
